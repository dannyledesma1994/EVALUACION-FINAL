package com.mycompany.taller;

import com.mycompany.taller.igu.Principal;

public class Taller {

    public static void main(String[] args) {

        Principal inicio = new Principal();
        inicio.setVisible(true);
        inicio.setLocationRelativeTo(null);
    
}
}
